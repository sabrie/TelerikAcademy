﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _02.SumNumbers_MVC.Models
{
    public class Summator
    {
        public decimal FirstNumber { get; set; }

        public decimal SecondNumber { get; set; }

        public decimal Sum { get; set; }
    }
}